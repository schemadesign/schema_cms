
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.3.1'
version = '1.3.1'
full_version = '1.3.1'
git_revision = '4bfc152f6ee1ca48c73c06e27f7ef021d729f496'
release = True

if not release:
    version = full_version
